// Conditional Statements
// Comparison Operators
// >, <, >=, <=, ==, ===, !=, !==
// else if and !

const num1 = 6;
const num2 = 6;
const result = num1 >= num2;

const value = false;

if (!value) {
  console.log('value is false');
}

// if (num1 > num2) {
//   console.log('first number is bigger than second');
// } else if (result) {
//   console.log('first number equal to a second');
// } else {
//   console.log('second number is bigger than first');
// }
