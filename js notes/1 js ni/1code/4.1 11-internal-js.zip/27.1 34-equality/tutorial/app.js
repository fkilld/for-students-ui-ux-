// Conditional Statements
// Comparison Operators
// >, <, >=, <=, ==, ===, !=, !==
// == checks only value
// === checks value and type

const num1 = 6;
const num2 = '6';

const value = num1 != num2;
const value2 = num1 !== num2;

console.log(value);
console.log(value2);
