// document.write('hello world');
// alert('hello world');
// console.log('hello world);

document.write({ name: 'john' })
alert({ name: 'john' })
console.log({ name: 'john' })
