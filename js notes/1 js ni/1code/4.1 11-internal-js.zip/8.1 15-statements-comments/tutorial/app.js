// I woke,? up early!!!! him today.
// statements - sets of instructions
// comments - shortcut Command + /

// this is console statement
// console.log("hello world");
/*
console.log("hello people");
console.log("hello my friend bob");
console.log("hello susan");
document.write("hello anna");
*/
console.log("hello people");
