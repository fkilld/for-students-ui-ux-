// Logical Operators
// (|| - OR), (&& - AND), !

const name = 'peter';
const age = 24;

if (name !== 'bob' && age === 24) {
  console.log('hello there user');
} else {
  console.log('wrong values');
}
