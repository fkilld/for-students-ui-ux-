// Numbers
// Loosely Typed = don't declare type

const number = 34;
// let pants = 2.466;
// pants = 'are great';
const number2 = 2.456;
const number3 = '2.456';

const add = number + number2;
const sub = number - number2;
const mult = number * number2;
const div = number / number2;

console.log(add);
console.log(sub);
console.log(mult);
console.log(div);
console.log(number3);
