// Loops
// repeatedly run a block of code while condition is true
// for loop

// let i;
// for (i = 0; i < 10; i++) {
//   console.log('and the number is : ' + i);
// }

for (let number = 11; number >= 0; number--) {
  console.log('and the number is : ' + number)
}
